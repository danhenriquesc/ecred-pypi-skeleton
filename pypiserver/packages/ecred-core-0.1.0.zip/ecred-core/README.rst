ecred-core
============

Core of e-cred