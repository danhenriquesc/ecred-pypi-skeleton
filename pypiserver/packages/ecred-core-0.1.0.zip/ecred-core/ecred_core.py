__version__ = '0.1.0'


def helloWorld():
    print "Yes! I'm working!"
